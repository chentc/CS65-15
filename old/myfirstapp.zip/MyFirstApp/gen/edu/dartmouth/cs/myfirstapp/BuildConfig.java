/** Automatically generated file. DO NOT MODIFY */
package edu.dartmouth.cs.myfirstapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}